package my.vaadin.vcapp;

//Enum Klasse mit allen Moeglichkeiten fuer die Datumsauswahl
public enum TaskDateSpecification {
	Fixdatum, AuswahlDatum, KeinDatum, Deadline

}
