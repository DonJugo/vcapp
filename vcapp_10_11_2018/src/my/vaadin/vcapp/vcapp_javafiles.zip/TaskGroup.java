package my.vaadin.vcapp;

//Enumklasse zum repraesentieren aller Aufgabenkategorien
public enum TaskGroup {
	Kueche, Garten, Mittagessen, Weihnachtsfeier

}
